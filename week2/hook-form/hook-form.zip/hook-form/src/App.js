import HookForm from './components/HookForm';
import './App.css';
// import Container from 'react-bootstrap/Container';
// ^^ Ill figure this out here shortly. Works fine I just suck with Bootstrap right now.


function App() {
  return (
      <div className="App">
        <HookForm/>
      </div>
  );
}

export default App;
